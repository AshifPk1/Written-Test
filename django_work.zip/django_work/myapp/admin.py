from django.contrib import admin
from . models import Tenant

admin.site.register(Tenant)
